﻿Imports MySql.Data.MySqlClient

Public Class Loginform
    Dim conn As MySqlConnection
    Dim command As MySqlCommand
    Dim reader As MySqlDataReader
    Dim insertstring As String


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Btn1_Click(sender As Object, e As EventArgs) Handles Btn1.Click
        SignUpForm.Show()
    End Sub

    Private Sub Btn2_Click(sender As Object, e As EventArgs) Handles Btn2.Click
        Dim conn As New MySqlConnection
        Dim reader As MySqlDataReader
        conn.ConnectionString = "server=localhost;userid=root;password=;database=ragav"
        Try
            conn.Open()
            Dim query As String
            query = "select * from ragav.mobile where username='" & TextBox1.Text & "' and password='" & TextBox2.Text & "'"
            command = New MySqlCommand(query, conn)
            reader = command.ExecuteReader
            Dim count As Integer
            count = 0
            While reader.Read
                count = count + 1
            End While
            If count = 1 Then
                Me.Hide()
                Form4.Show()
            ElseIf count > 1 Then
                MessageBox.Show("username and password are incorrect")
            Else
                MessageBox.Show("username and password are incorrect")
            End If

        Catch ex As MySqlException

        Finally

        End Try

    End Sub

    Private Sub Lbl3_Click(sender As Object, e As EventArgs) Handles Lbl3.Click

    End Sub
End Class
