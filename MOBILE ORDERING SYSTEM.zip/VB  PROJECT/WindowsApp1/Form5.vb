﻿Public Class Form5

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Visible = False
        Form4.Show()
        TextBox1.Text() = ""
        TextBox2.Text() = ""
        TextBox3.Text() = ""
        ComboBox1.Text() = ""
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MessageBox.Show("Ordered Successfully")
        Me.Hide()
        Form3.Show()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedItem = "Oppo" Then
            TextBox2.Text = "1831009"
        ElseIf ComboBox1.SelectedItem = "Real Me" Then
            TextBox2.Text = "1831010"
        ElseIf ComboBox1.SelectedItem = "Samsung" Then
            TextBox2.Text = "1831011"
        ElseIf ComboBox1.SelectedItem = "Vivo V11" Then
            TextBox2.Text = "1831003"
        ElseIf ComboBox1.SelectedItem = "iPhone X" Then
            TextBox2.Text = "1831044"
        ElseIf ComboBox1.SelectedItem = "Moto" Then
            TextBox2.Text = "1831006"
        End If
    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged
        Dim a As Integer
        a = Val(TextBox3.Text)
        If ComboBox1.SelectedItem = "Oppo" Then
            TextBox1.Text = a * "15000"
        ElseIf ComboBox1.SelectedItem = "Samsung" Then
            TextBox1.Text = a * "12000"
        ElseIf ComboBox1.SelectedItem = "Real Me" Then
            TextBox1.Text = a * "15000"
        ElseIf ComboBox1.SelectedItem = "iPhone X" Then
            TextBox1.Text = a * "25000"
        ElseIf ComboBox1.SelectedItem = "Vivi V11" Then
            TextBox1.Text = a * "1500"
        ElseIf ComboBox1.SelectedItem = "Moto" Then
            TextBox1.Text = a * "20000"
        End If
    End Sub
End Class