﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SignUpForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SignUpForm))
        Me.Lbl1 = New System.Windows.Forms.Label()
        Me.Lbl2 = New System.Windows.Forms.Label()
        Me.Lbl3 = New System.Windows.Forms.Label()
        Me.Lbl4 = New System.Windows.Forms.Label()
        Me.Lbl5 = New System.Windows.Forms.Label()
        Me.Lbl6 = New System.Windows.Forms.Label()
        Me.Txt1 = New System.Windows.Forms.TextBox()
        Me.Txt2 = New System.Windows.Forms.TextBox()
        Me.Txt3 = New System.Windows.Forms.TextBox()
        Me.Txt4 = New System.Windows.Forms.TextBox()
        Me.Txt5 = New System.Windows.Forms.TextBox()
        Me.Lbl7 = New System.Windows.Forms.Label()
        Me.Btn1 = New System.Windows.Forms.Button()
        Me.Btn2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Lbl1
        '
        Me.Lbl1.AutoSize = True
        Me.Lbl1.Font = New System.Drawing.Font("Ravie", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl1.Location = New System.Drawing.Point(392, 54)
        Me.Lbl1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Lbl1.Name = "Lbl1"
        Me.Lbl1.Size = New System.Drawing.Size(364, 34)
        Me.Lbl1.TabIndex = 0
        Me.Lbl1.Text = "Sign Up  Registration"
        '
        'Lbl2
        '
        Me.Lbl2.AutoSize = True
        Me.Lbl2.Location = New System.Drawing.Point(327, 175)
        Me.Lbl2.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Lbl2.Name = "Lbl2"
        Me.Lbl2.Size = New System.Drawing.Size(137, 22)
        Me.Lbl2.TabIndex = 1
        Me.Lbl2.Text = "First Name"
        '
        'Lbl3
        '
        Me.Lbl3.AutoSize = True
        Me.Lbl3.Location = New System.Drawing.Point(327, 243)
        Me.Lbl3.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Lbl3.Name = "Lbl3"
        Me.Lbl3.Size = New System.Drawing.Size(131, 22)
        Me.Lbl3.TabIndex = 2
        Me.Lbl3.Text = "Last Name"
        '
        'Lbl4
        '
        Me.Lbl4.AutoSize = True
        Me.Lbl4.Location = New System.Drawing.Point(337, 365)
        Me.Lbl4.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Lbl4.Name = "Lbl4"
        Me.Lbl4.Size = New System.Drawing.Size(121, 22)
        Me.Lbl4.TabIndex = 3
        Me.Lbl4.Text = "Password"
        '
        'Lbl5
        '
        Me.Lbl5.AutoSize = True
        Me.Lbl5.Location = New System.Drawing.Point(316, 412)
        Me.Lbl5.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Lbl5.Name = "Lbl5"
        Me.Lbl5.Size = New System.Drawing.Size(224, 22)
        Me.Lbl5.TabIndex = 4
        Me.Lbl5.Text = "Conform Password"
        '
        'Lbl6
        '
        Me.Lbl6.AutoSize = True
        Me.Lbl6.Location = New System.Drawing.Point(327, 475)
        Me.Lbl6.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Lbl6.Name = "Lbl6"
        Me.Lbl6.Size = New System.Drawing.Size(114, 22)
        Me.Lbl6.TabIndex = 5
        Me.Lbl6.Text = "E-Mail Id"
        '
        'Txt1
        '
        Me.Txt1.Location = New System.Drawing.Point(663, 175)
        Me.Txt1.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Txt1.Name = "Txt1"
        Me.Txt1.Size = New System.Drawing.Size(172, 30)
        Me.Txt1.TabIndex = 6
        '
        'Txt2
        '
        Me.Txt2.Location = New System.Drawing.Point(663, 243)
        Me.Txt2.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Txt2.Name = "Txt2"
        Me.Txt2.Size = New System.Drawing.Size(172, 30)
        Me.Txt2.TabIndex = 7
        '
        'Txt3
        '
        Me.Txt3.Location = New System.Drawing.Point(663, 365)
        Me.Txt3.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Txt3.Name = "Txt3"
        Me.Txt3.Size = New System.Drawing.Size(172, 30)
        Me.Txt3.TabIndex = 8
        Me.Txt3.UseSystemPasswordChar = True
        '
        'Txt4
        '
        Me.Txt4.Location = New System.Drawing.Point(663, 412)
        Me.Txt4.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Txt4.Name = "Txt4"
        Me.Txt4.Size = New System.Drawing.Size(172, 30)
        Me.Txt4.TabIndex = 9
        Me.Txt4.UseSystemPasswordChar = True
        '
        'Txt5
        '
        Me.Txt5.Location = New System.Drawing.Point(663, 467)
        Me.Txt5.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Txt5.Name = "Txt5"
        Me.Txt5.Size = New System.Drawing.Size(172, 30)
        Me.Txt5.TabIndex = 10
        '
        'Lbl7
        '
        Me.Lbl7.AutoSize = True
        Me.Lbl7.Location = New System.Drawing.Point(51, 18)
        Me.Lbl7.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Lbl7.Name = "Lbl7"
        Me.Lbl7.Size = New System.Drawing.Size(0, 22)
        Me.Lbl7.TabIndex = 11
        '
        'Btn1
        '
        Me.Btn1.Location = New System.Drawing.Point(369, 575)
        Me.Btn1.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Btn1.Name = "Btn1"
        Me.Btn1.Size = New System.Drawing.Size(131, 32)
        Me.Btn1.TabIndex = 12
        Me.Btn1.Text = "Submit"
        Me.Btn1.UseVisualStyleBackColor = True
        '
        'Btn2
        '
        Me.Btn2.Location = New System.Drawing.Point(571, 575)
        Me.Btn2.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Btn2.Name = "Btn2"
        Me.Btn2.Size = New System.Drawing.Size(131, 32)
        Me.Btn2.TabIndex = 13
        Me.Btn2.Text = "Reset"
        Me.Btn2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(74, 61)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 32)
        Me.Button1.TabIndex = 14
        Me.Button1.Text = "Back"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(663, 303)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(133, 30)
        Me.TextBox1.TabIndex = 15
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(344, 314)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(120, 22)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "username"
        '
        'SignUpForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(14.0!, 22.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(926, 682)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Btn2)
        Me.Controls.Add(Me.Btn1)
        Me.Controls.Add(Me.Lbl7)
        Me.Controls.Add(Me.Txt5)
        Me.Controls.Add(Me.Txt4)
        Me.Controls.Add(Me.Txt3)
        Me.Controls.Add(Me.Txt2)
        Me.Controls.Add(Me.Txt1)
        Me.Controls.Add(Me.Lbl6)
        Me.Controls.Add(Me.Lbl5)
        Me.Controls.Add(Me.Lbl4)
        Me.Controls.Add(Me.Lbl3)
        Me.Controls.Add(Me.Lbl2)
        Me.Controls.Add(Me.Lbl1)
        Me.Font = New System.Drawing.Font("Ravie", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Name = "SignUpForm"
        Me.Text = "`"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Lbl1 As Label
    Friend WithEvents Lbl2 As Label
    Friend WithEvents Lbl3 As Label
    Friend WithEvents Lbl4 As Label
    Friend WithEvents Lbl5 As Label
    Friend WithEvents Lbl6 As Label
    Friend WithEvents Txt1 As TextBox
    Friend WithEvents Txt2 As TextBox
    Friend WithEvents Txt3 As TextBox
    Friend WithEvents Txt4 As TextBox
    Friend WithEvents Txt5 As TextBox
    Friend WithEvents Lbl7 As Label
    Friend WithEvents Btn1 As Button
    Friend WithEvents Btn2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
