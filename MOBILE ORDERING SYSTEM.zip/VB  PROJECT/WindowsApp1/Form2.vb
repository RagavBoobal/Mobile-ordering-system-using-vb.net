﻿Imports MySql.Data.MySqlClient

Public Class SignUpForm
    Dim conn As MySqlConnection
    Dim command As MySqlCommand
    Dim reader As MySqlDataReader
    Dim insertstring As String
    Dim comman As MySqlCommand


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Visible = False
        Form3.Show()
    End Sub

    Private Sub Btn1_Click(sender As Object, e As EventArgs) Handles Btn1.Click
        conn = New MySqlConnection
        conn.ConnectionString = "server=localhost;userid=root;password=;database=ragav"

        Try
            conn.Open()
            MessageBox.Show("connected")
            insertstring = "INSERT INTO `mobile`(`firstname`, `lastname`, `username`, `password`, `repassword`, `emailid`) VALUES ('" & Txt1.Text & "','" & Txt2.Text & "','" & TextBox1.Text & "','" & Txt3.Text & "','" & Txt4.Text & "','" & Txt5.Text & "')"
            command = New MySqlCommand(insertstring, conn)
            reader = command.ExecuteReader
            Dim comman As New MySqlCommand("select *from data where username= username", conn)
            Form4.Show()
            conn.Close()
        Catch ex As MySqlException

        Finally
            conn.Dispose()

        End Try

    End Sub

    Private Sub SignUpForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class